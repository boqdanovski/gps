package com.example.gpsspeed

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .callTimeout(10, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    private const val ENDPOINT = "https://a3936.ru/main/downloads-2/02.txt"

    fun postSpeedKmh(speedKmh: Double) {
        val payload = """{"speedKmh": ${"%.3f".format(speedKmh)}}"""
        val request = Request.Builder()
            .url(ENDPOINT)
            .post(payload.toRequestBody(json))
            .build()
        client.newCall(request).execute().use { /* optional check */ }
    }
}
